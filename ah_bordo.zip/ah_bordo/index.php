<!DOCTYPE html>
<html lang="pt-br">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"><!--link para o estilo externo do template-->
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <link rel="icon" href="icones/ahbordo_icone.png">
      <title>Ah Bordo | Home</title>
      <link rel="stylesheet" href="estilos/index.css"><!--link para o estilo da pagina inicial-->
      <link rel="stylesheet" href="js/index.css"><!--link para o js da pagina inicial-->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
      <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
      <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <link href="https://fonts.googleapis.com/css?family=Raleway:800,300" rel="stylesheet" type="text/css"/>
   </head>
<body>
<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-wide w3-padding w3-card ">
    <a href="index.html" class="w3-bar-item"><img src="imagens/ahbordo_logo.png" style="width: 20%;"></a>
    <!-- Float links to the right. Hide them on small screens -->
    <div class="w3-right">
      <a href="voluntariado.html" class="w3-bar-item w3-button">Bora ajudar?</a>
      <a href="transporte.html" class="w3-bar-item w3-button">Fui!</a>
      <a href="mepoupe.html" class="w3-bar-item w3-button">Me poupe!</a>
      <a href="destinos.html" class="w3-bar-item w3-button">Brota aí!</a>
      <a href="cadastro.html" class="w3-bar-item w3-button">Cadastro</a>
      <a href="login.html" class="w3-bar-item w3-button">Login</a>
    </div>
  </div>
</div>
<header></header>
         <!--termina a navbar-->
         <section class=" col l2 md6 s3 height-20"><!--ocupa uma seção da pagina-->
            <p>Aqui te incentivamos a ser mais independente!</p>
      </section>
         <section class=" col l2 md6 s3 height-75"><!--ocupa 78 da pagina-->
      <div class="content">
            <p>O Ah Bordo foi criado para ajudar jovens a fazer a 1ª viagem usando o próprio dinheiro. Seja começando um négocio de bolos ou trabalhando enquanto viaja, consideramos suas skills do mundo real, ou seja, suas habilidades e experiências não profissionais.</p>
            </div>
         </section>
         </section>
         <section class="col l2 md6 s1 height-88"><!--ocupa 80 da pagina-->
      <div class="content">
        <h1>É fácil.</h1>
        <p>Aqui voce escolhe pra onde vai, tem dicas de como chegar lá e ainda junta uma grana ajudando o lugar onde vai se hospedar.</p><a href="cadastro.html"><button class="w3-button w3-light-grey w3-block" >Vamos começar?</a></button>
      </div>
    </section>
   <!-- Seção sobre as pessoas -->
   <div class="container">
   <p style="text-align: center;">Sobre Nós</p>
    <div class="w3-row-padding w3-grayscale w3-padding-32"style="padding-left: 10em ;">
      <div class="w3-col l2 m6 s10 w3-margin-bottom" >
        <img src="imagens/bruna.jpg" alt="Bruna" style="width:100%">
        <h3>Bruna Luiza</h3>
        <h4 class="w3-opacity">Fundadora<br>Gerente</h4>
      </div>
      <div class="w3-col l2 m6  s10 w3-margin-bottom">
        <img src="imagens/hayme.jpg" alt="Haymê" style="width:100%">
        <h3>Haymê M.</h3>
        <h4 class="w3-opacity">Fundadora<br>Analista</h4>
      </div>
      <div class="w3-col l2 m6 s10 w3-margin-bottom">
        <img src="imagens/le.jpg" alt="Letícia" style="width:100%">
        <h3>Letícia Alves</h3>
        <h4 class="w3-opacity">Fundadora<br>Designer</h4>
      </div>
      <div class="w3-col l2 m6 s10 w3-margin-bottom">
        <img src="imagens/nat4.jpg" alt="Natália" style="width:100%">
        <h3>Natália Silva</h3>
        <h4 class="w3-opacity">Fundadora<br>Programadora</h4>
      </div>
      <div class="w3-col l2 m6 s10 w3-margin-bottom">
        <img src="imagens/matheus.jpg" alt="Matheus" style="width:100%">
        <h3>Matheus S.</h3>
        <h4 class="w3-opacity">Fundador<br>Pesquisador</h4>
      </div>
    </div>
    </div>
<!-- final do conteúdo da página -->
</div>
      <!-- Rodapé -->
    <link rel="stylesheet" href="estilos/rodape.css"><!--link para o estilo do rodapé-->
   <section id="footer">
      <div class="container">
         <div class="row text-center text-xs-center text-sm-left text-md-left">
            <div class="col-xs-12 col-sm-4 col-md-4">
               <img id="logo" src="imagens/ahbordo_logo.png" style="width: 500px;height: 300px;">
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4">
               <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
               <ul class="list-unstyled list-inline social text-center">
                  <li class="list-inline-item"><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-facebook"></i></a></li>
                  <li class="list-inline-item"><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-twitter"></i></a></li>
                  <li class="list-inline-item"><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-instagram"></i></a></li>
                  <li class="list-inline-item"><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-google-plus"></i></a></li>
                  <li class="list-inline-item"><a href="https://www.fiverr.com/share/qb8D02" target="_blank"><i class="fa fa-envelope"></i></a></li>
               </ul>
            </div>
            <hr>
         </div>   
         <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
               <p><h6>Ah Bordo com você.</h6> </p>
               <p class="h6">© Todos os Direitos reservados. Imagens by<a href="http://www.freepik.com">Freepik Template by <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank">w3.css</a></p>
            </div>
            <hr>
         </div>   
      </div>
   </section>
   </div>
   <!-- fim rodapé -->
   </body>
</html>